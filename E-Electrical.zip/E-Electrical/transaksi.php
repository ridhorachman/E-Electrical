<?php
	include"koneksi.php";

	  $id    =  $_GET['id'];

	  $min = '1';
	  $max = '1000';
	  $sql = "select * from barang where id = '$id' ";
      $data = $pdo->prepare($sql);
      $data->execute();
      $row = $data->fetch(PDO::FETCH_ASSOC);
      
      $gambar = $row['gambar'];
      $deskripsi = $row['deskripsi'];
      $id_kategori = $row['id_kategori'];
      $jumlah_lama = $row['jumlah'];
      $jumlah_ambil = $_POST ['jumlah'];
      $jum_baru = $jumlah_lama - $jumlah_ambil;
      $id_transaksi= rand($min,$max);

      
      session_start();

      if($jumlah_lama < $jumlah_ambil){
      		echo "error,  data pemesanan terlalu banyak"; }
      		else{ 
				if(isset($_POST['beli'])){
				try{
					$sql	= 'insert into transaksi set id_transaksi = ?,id = ?,email = ?,nama_barang = ?, jumlah_beli = ?';

					$email = $_SESSION['email'];
					$query = $pdo->prepare($sql);
					$query -> bindParam (1, $id_transaksi);
					$query -> bindParam (2, $_POST['id']);
					$query -> bindParam (3, $email);
					$query -> bindParam (4, $_POST['nama_barang']);
					$query -> bindParam (5, $_POST['jumlah']);
					

					if($query->execute()){
							header('location: index.php');
					}else{
						die('gagal menambah');
					}
					} 
					catch (PDOException $e) {
				   // tampilkan pesan kesalahan jika koneksi gagal
				   print "Koneksi atau query bermasalah: " . $e->getMessage() . "<br/>";
				   die();
				}

				if(isset($_POST['beli'])){
				try{
					$sql	= 'update barang set nama_barang = :nama_barang,gambar = :gambar,deskripsi= :deskripsi,harga = :harga,jumlah = :jumlah , id_kategori= :id_kategori WHERE id = :id';

					$query = $pdo->prepare($sql);
				 	/*$query=$this->db->prepare("UPDATE barang SET id = :id,nama_barang = :nama_barang,gambar = :gambar,deskripsi= :deskripsi,harga = :harga,jumlah = :jumlah , id_kategori= :id_kategori WHERE id=:id ");*/
					$query -> bindParam (':id', $_POST['id']);
					$query -> bindParam (':nama_barang', $_POST['nama_barang']);
					$query -> bindParam (':gambar', $gambar);
					$query -> bindParam (':deskripsi', $deskripsi);
					$query -> bindParam (':harga', $_POST['harga']);
					$query -> bindParam (':jumlah', $jum_baru);
					$query -> bindParam (':id_kategori', $id_kategori);

					if($query->execute()){
							header('location: index.php');
					}else{
						die('gagal mengedit');
					}
					} 
					catch (PDOException $e) {
				   // tampilkan pesan kesalahan jika koneksi gagal
				   print "Koneksi atau query bermasalah: " . $e->getMessage() . "<br/>";
				   die();
				}
}

				}

				}


?>